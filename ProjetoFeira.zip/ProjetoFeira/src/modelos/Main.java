package modelos;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Digite o tipo de produto: ");
        String tipo = scr.nextLine();

        System.out.println("Produto: " + tipo);

    }
}
